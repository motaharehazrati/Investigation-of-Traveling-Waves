clear
clc
%time-freq
load('ArrayData.mat')
load('CleanTrials')
figure
fs=200;
for j=[2,4:48]
    x = mean(chan(j).lfp(:,Intersect_Clean_Trials),2);
    hold on
    fs = 1000;
    [S,F,T] = spectrogram(x,100,98,128,fs);
    helperCWTTimeFreqPlot(S,T,F,'surf','STFT of my signal','Seconds','Hz')    
end
ylim([0 45])
figure
f=[];
channel_list=[];
domnf=[];
for j=[2,4:48]
      x = mean(chan(j).lfp(:,Intersect_Clean_Trials),2);
      y=abs(fft(x,641));
      y=y(1:321);
      [v,k] = max(y); % find maximum
      f_scale = ((0.001:641/2)* fs/641)'; % frequency scale
      %plot(f_scale, y);
      %fest = f_scale(k);
%        domf(j)=max(y);
     f_scale_log=  log10(f_scale);
     y_log=log10(y);
     [p,~] = polyfit(f_scale_log,y_log,1);
     fitted_y_log=(f_scale_log) *p(1)+p(2);
     noise_cancelation=y_log-fitted_y_log;
     maxa=max(noise_cancelation);
     maxf_index=find(noise_cancelation==maxa);
     maxf=f_scale(maxf_index);
     channel_list=[channel_list j];
     domnf=[domnf maxf];
     
%      [val k1]=max(f);
 %     domf(j)=10.^f_scale(k1);
end
save dominant_frequency domnf

counter=1;
% for ch=1:48
%     if ch==1 || ch==3 || ch==5
%         topo(ch)=0;
%     
%     else
%        topo(ch)=domnf(counter);
%        counter=counter+1;
%     end
% end
% imagesc([0 10],[0 5],topo);   
    
% j=[2,4:48];
ch=1;
for i = 1:5
    for k = 1:10
        
            
          if (i==1 || i==5 || i==2 || i==4)&& k==1
            topo(i,k)=0;
    
          else
            topo(i,k)=domnf(counter);
            counter=counter+1;
          end
       
          
          
        
    end
end
imagesc(topo);
% imagesc(ch)
set(gca,'YDir','normal')
colorbar
% figure;
% stem(1:48,domf/1000);
% xlabel('channel');
% ylabel('dominant frequency');
figure

plot(f_scale_log,fitted_y_log,'p');
hold on
plot(f_scale_log,y_log,'r');
hold on
plot(f_scale_log,y_log-fitted_y_log,'k')
xlabel('log frequncy')
ylabel('log fft')
legend('color noise','fft before cancelation','fft after cancelation');
title('color noise cancelation');
figure
stem(channel_list,domnf);
ylabel('dominant frequencies')
xlabel('channels')
figure
% plot(f_scale,





j=[2,4:48];
for j=[2,4:48]
     x = mean(chan(j).lfp(:,Intersect_Clean_Trials),2);
     [pxx,f] = pwelch(x,[],[0],[],fs);
     f_log=  log10(f);
     y_log=log10(pxx);
     [p,~] = polyfit(f_log(2:end),y_log(2:end),1);
     fitted_y_log=(f_log) *p(1)+p(2);
     raw_pow_log = log10(pxx);
     pow_log= raw_pow_log-fitted_y_log ;
     
     plot(f_log,pow_log)
     hold on
end
xlabel('log frequency')
ylabel('log power')
xlim([0.5 2.7]);
figure;
imagesc(1:46,f,raw_pow_log)

      


