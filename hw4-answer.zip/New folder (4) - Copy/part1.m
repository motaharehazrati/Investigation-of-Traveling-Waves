clear
clc
close all;
%not processed
load('ArrayData.mat')
for i=1:1:length(chan)
    plot(Time,mean(chan(i).lfp,2))
    hold on
end
xlim([-1.2 2])
xlabel('time');
ylabel('LFP');
%pre processing
load('CleanTrials')
figure
for j=[2,4:48]
    plot(Time,mean(chan(j).lfp(:,Intersect_Clean_Trials),2))
    hold on
end
xlim([-1.2 2])
xlabel('time');
ylabel('LFP after preprocessing');
%spectogram
figure
for j=[2,4:48]
    spectrogram(mean(chan(j).lfp(:,Intersect_Clean_Trials),2),[3 1 2]);
%      imagesc(s)
    hold on
end
title('spectogram of all the clean trials in diffrent channels')
set(gca, 'YDir', 'normal');
% plot(s)
figure
for j=[2,4:48]
    imagesc(mean(chan(j).lfp(:,Intersect_Clean_Trials),2));
    hold on
end
figure
for i=1:1:length(chan)
    for k=1:1:823
        p= abs(fft(chan(i).lfp(:,k)))/k;
    
    end
    imagesc(p);hold on
end


