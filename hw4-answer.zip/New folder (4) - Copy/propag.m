clear
clc
%phase propagation
load('ArrayData.mat')
load('CleanTrials')
load('dominant_frequency')
counter=1;
fs=200;
for j=[2,4:48]
    filtered_x=[];
    for i=1:length(Intersect_Clean_Trials)
        x = chan(j).lfp(:,i);
        f_low=domnf(counter)-1;
        f_high=domnf(counter)+1;
        [b,a]=butter(2,[f_low/(fs/2) f_high/(fs/2)],'bandpass');
        filtered_x=[filtered_x filtfilt(b,a,x)];
    end
    all_filtered_x{counter}=filtered_x;
    counter=counter+1;
end
phi=zeros(7,7,490,641);
j=1;
% for j=1:length(all_filtered_x)
%     
%     filtered_xx=cell2mat(all_filtered_x(j));
    for ii=1:7
        
        for jj=1:7
            filtered_xx=cell2mat(all_filtered_x(j));
            if (ii==1 && jj==1) || (ii==1 && jj==2) || (ii==1 && jj==3)
                phi(ii,jj,:,:)=NaN;
            else
                for k=1:size(filtered_xx,2)
                    trial=filtered_xx(:,k);
                    h=hilbert(trial);
                    h1 = trial + i * h;
                    phi(ii,jj,k,:) = angle(h1);
                end
                j=j+1;
            end
            
        end
        
    end
% end
cosphi=cos(phi);  
figure
for t=1:length(Time)
    imagesc(cos(phi(:,:,24,t)))
end
d1=[];
trial=24;
%pgd
fynew = [];
fxnew = [];
for t=1:length(Time)
    [fx,fy]= gradient(phi(:,:,24,t));
    for iy = 1: 7
        for ix = 1: 7
            if(~isnan(find(fy(iy, ix))) && ~isnan(find(fx(iy, ix))))
                fxnew = [fxnew  fx(iy, ix)];
                fynew = [fynew  fy(iy, ix)];
                d=norm([fxnew(5:end),fynew([4,5,6,7,11:end])]);
%                 d=norm([fxnew(5:end),fynew([7,11:end])]);
                d1=[d1 d];
            end
        end
    end
    normavg(t) =norm(mean(fxnew(5:end)), mean(fynew([4,5,6,7,11:end])));
    n(t) = mean(d1);
     pgd(t) = normavg / n;
%     plot(t,pgd);
  %  hold on

end
%speed
for t=1:640
        for ix=1:7
            for iy=1:7
                dphi(ix,iy,24,t)=phi(ix,iy,24,t+1)-phi(ix,iy,24,t);
            end
        end
%        avgspeeddphi=(mean(dphi));
%        totalspeed=avgspeeddphi/n;
        
end    
%direction
for t=1:641
    [fx,fy]= gradient(phi(:,:,24,t));
    fynew = [];
    fxnew = [];
    for iy = 1: 7
        for ix = 1: 7
            if(~isnan(find(fy(iy, ix))) && ~isnan(find(fx(iy, ix))))
                fxnew = [fxnew  fx(iy, ix)];
                fynew = [fynew  fy(iy, ix)];
            end
        end
    end
    mfx(t)=mean(fxnew(5:end));
    mfy(t)=mean(fynew([4,5,6,7,11:end]));
    direction(t)=atand(mfx/mfy);
end
        