%demo files
%after runing propag
load('cosphi')
v = VideoWriter('demovideo.avi');
open(v)
for t= 1:length(Time)
    subplot(2,2,1)
    imagesc(cosphi(:,:,24,t));
    hold on
    quiver(1:7, 1:7, fx, fy);
%     compass(fx,fy);
    set(gca);
    colorbar;
    title('cosphi');
    frame = getframe(gcf);
%     writeVideo(v,frame);
    pause(0.1);
    subplot(2,2,2)
    plot(Time(t),pgd);
    subplot(2,2,3)
%     plot(1:640,speed);
    subplot(2,2,4)
    plot(Time(t),direction)
%     plot(
    
end
close(v)