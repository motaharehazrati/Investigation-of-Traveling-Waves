clear
clc
load('ArrayData.mat')
load('CleanTrials')
fs=200;
raw_pow=[];
pow=[];

for j=[2,4:48]
     x = mean(chan(j).lfp(:,Intersect_Clean_Trials),2);
     [pxx,f] = pwelch(x,[],0,[],fs);
     f_log=  log10(f);
     y_log=log10(pxx);
     [p,~] = polyfit(f_log(2:end),y_log(2:end),1);
     fitted_y_log=(f_log) *p(1)+p(2);
     raw_pow = [raw_pow, log10(pxx)];
     pow = [raw_pow, log10(pxx)-fitted_y_log];
%      
%      plot(f_log,pow_log)
%      hold on
end

figure;

imagesc([2,4:48],f,pow)
set(gca,'YDir', 'normal')
xlabel('channels');
ylabel('Hz');
colorbar